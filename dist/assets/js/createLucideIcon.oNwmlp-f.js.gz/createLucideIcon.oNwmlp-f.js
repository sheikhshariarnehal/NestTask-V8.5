import{r as o}from"./index.CFfqBDDG.js";/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var w={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().trim(),b=(e,n)=>{const a=o.forwardRef(({color:c="currentColor",size:r=24,strokeWidth:s=2,absoluteStrokeWidth:i,className:u="",children:t,...l},m)=>o.createElement("svg",{ref:m,...w,width:r,height:r,stroke:c,strokeWidth:i?Number(s)*24/Number(r):s,className:["lucide",`lucide-${g(e)}`,u].join(" "),...l},[...n.map(([d,p])=>o.createElement(d,p)),...Array.isArray(t)?t:[t]]));return a.displayName=`${e}`,a};export{b as c};
